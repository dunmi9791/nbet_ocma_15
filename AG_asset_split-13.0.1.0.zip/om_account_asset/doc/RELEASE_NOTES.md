## Module <om_account_asset>

#### 28.02.2022
#### Version 13.0.4.2.0
##### IMP
- remove deprecated method

#### 28.02.2022
#### Version 13.0.4.1.0
##### IMP
- remove duplicated security update

#### 02.01.2022
#### Version 13.0.4.0.0
##### FIX
- asset currency issue

#### 24.12.2021
#### Version 13.0.3.0.0
##### FIX
- asset onchange issue

